import tkinter as tk
from tkinter import *
from PIL import ImageTk, Image
import csv
import Class
from tkinter import messagebox

AdminChanges = False ##flag determines whether changes have been made

def returnToMain(AdminChanges, window):
    if AdminChanges == True:
        messagebox.showwarning("Changes have been made to this account.","Changes have been made to this account. "+
                               "You may have to log out and log back in again for changes to appear.")
    window.destroy()
        
        
            
def addUser(usernEnt, passEnt):
    ##adds a new user 
    user=usernEnt.get()
    password=passEnt.get()
    adminUserNew=usernEnt.get()
    adminPassNew=passEnt.get()
    
    if user == '' and password == '':
        messagebox.showinfo('Add New User', "In order to add a new user, enter details in the boxes provided."
                            +" Then, press this button again to enter changes.")
    elif len(adminUserNew)<8 or len(adminPassNew)<8:
        messagebox.showwarning('Invalid Input', 'The username and password must be at least 8 characters long.')
        
    else:
        if messagebox.askyesno('Add New User', 'Add this user?'):
            with open ('CurrentUser.csv','r') as file:
                csvReader=csv.reader(file) 
                for SingleRow in csvReader:
                    CurrentAdmin = SingleRow[0]
            file.close()
                    
            with open('userLoginInfo.csv','a',newline='') as file:
                csvWriter=csv.writer(file)
                csvWriter.writerow([user,password,"FALSE"])
            file.close
            messagebox.showinfo("Action Successful", "Successfully added a new user.")
    

def changeAdmin(usernEnt, passEnt):
    ##changes the admin username and password and replaces all instances of username in files
    adminUserNew=usernEnt.get()
    adminPassNew=passEnt.get()
    
    if adminUserNew == '' and adminPassNew == '':
        messagebox.showinfo('Change Username and Password', "In order to change your username and passowrd, enter details in the boxes provided."
                            +" Then, press this button again to enter changes.")
    elif len(adminUserNew)<8 or len(adminPassNew)<8:
        messagebox.showwarning('Invalid Input', 'The username and password must be at least 8 characters long.')
        
    else:
        if messagebox.askyesno('Change Username and Passowrd', 'Change Admin username and password?'):
            L=[] ## 2D List to hold contents of file
            U = ''
            ##get the current user from text file
            with open('CurrentUser.txt', 'r') as f:
                U = f.read()
            f.close()
            
            ##move contents of file to list unless line contains current admin (user)
            with open('userLoginInfo.csv','r') as file:
                csvReader=csv.reader(file)
                for member in csvReader:
                    if(member[-1]=='TRUE'): ##search for Admin
                        continue ##if admin, do not append line to list
                    else:
                        L.append(member) ##append line of file to list
                L.append([adminUserNew,adminPassNew,'TRUE']) ##add new admin info at the end of list
            file.close()
            
            with open('userLoginInfo.csv','w',newline='') as file:
                csvWriter=csv.writer(file)
                csvWriter.writerows(L) ##rewrite file with updated info
            file.close()

            ##rewrite tasklist with updated admin username
            Contents=[]
            with open('taskList.csv', 'r') as fi:
                csvReader = csv.reader(fi)
                for task in csvReader:
                    if (task[0]==U):
                        task[0] = adminUserNew
                        Contents.append(task)
                    else:
                        Contents.append(task)       
            fi.close()
            
            with open('taskList.csv', 'w', newline='') as file:
                csvWriter = csv.writer(file)
                csvWriter.writerows(Contents)
            file.close()

            ##update current user file    
            with open('CurrentUser.txt','w') as f:
                f.write(adminUserNew)
            f.close()
            messagebox.showinfo('Successful Change', 'Successfully chnaged admin details.'+
                                "You will have to log out and log back in again to apply changes to main page.")    

def removeUser(usernEnt, passEnt):
    user=usernEnt.get()
    password=passEnt.get()

    U = ''
    ##get the current user from text file
    with open('CurrentUser.txt', 'r') as f:
        U = f.read()
    f.close()

    if user=="" and password =="":
        messagebox.showinfo('User not found.', 'Please enter the username and password of an existing user to delete their account.'+
                            " Then, press this button to finalize change.")
    else:
        if messagebox.askyesno('Remove User', 'Remove this user and their tasks for good?'):
            Contents=[]

            ##move contents of file to list unless line contains user to be removed 
            with open('userLoginInfo.csv','r') as file:
                csvReader=csv.reader(file)
                for member in csvReader:
                    if(member[0]==user and member[1]==password):
                        continue
                    else:
                        Contents.append(member)
            file.close()

            with open('userLoginInfo.csv','w',newline='') as file: ##write over file excluding removed user
                csvWriter=csv.writer(file)
                csvWriter.writerows(Contents)
            file.close()

            ##rewrite tasklist excluding the deleted user's tasks
            L=[]
            with open('taskList.csv', 'r') as file:
                csvReader = csv.reader(file)
                for task in csvReader:
                    if (task[0]==user):
                        continue
                    else:
                        L.append(task)
            file.close()
            
            with open('taskList.csv', 'w', newline='') as file:
                csvWriter = csv.writer(file)
                csvWriter.writerows(L)
            file.close()

            messagebox.showinfo('Action Successful', 'User successfully removed.')

def Set(window = None):
    
    '''window=tk.Tk()
    window.title('Settings')
    window.geometry('800x500')
    window.configure(bg = "Purple")'''

    if window is None:
        window = tk.Tk()

    window.title('Settings | Task Management System')
    window.geometry('800x500')
    window.grid_rowconfigure(1, weight=1)
    window.grid_columnconfigure(0, weight=1)
                           
    BodyFrame=tk.Frame(window,bg='purple',height=1000,width=1000)
    BodyFrame.pack()

    # Image
    img=Image.open("SetPage.jpg")
    resized_image=img.resize((200,200), Image.Resampling.LANCZOS)
    new_image=ImageTk.PhotoImage(resized_image)
    label=Label(BodyFrame, image=new_image)
    label.place(x=550,y=10)
    
    titleLab=tk.Label(BodyFrame,text="Admin Settings", bg='purple', fg = 'white', font = ('Times New Roman', 30))
    titleLab.place(x=270,y=10)

    usernLab=tk.Label(BodyFrame,text="Username: ",bg='purple', fg = 'white', font = ('Times New Roman', 12))
    usernLab.place(x=500,y=250)

    usernEnt=tk.Entry(BodyFrame)
    usernEnt.place(x=600,y=250)

    passLab=tk.Label(BodyFrame, text="Password: ",bg='purple', fg = 'white', font = ('Times New Roman', 12))
    passLab.place(x=500,y=300)

    passEnt=tk.Entry(BodyFrame)
    passEnt.place(x=600,y=300)

    chgAdminBut=tk.Button(BodyFrame, text='Change Admin Details', padx = 10, command=lambda:changeAdmin(usernEnt, passEnt))
    chgAdminBut.place(x=70,y=150)

    adduserBut=tk.Button(BodyFrame, text="Add New User", padx = 10, command=lambda:addUser(usernEnt, passEnt)) 
    adduserBut.place(x=70,y=230)

    chgpassBut=tk.Button(BodyFrame, text="Remove User", padx = 10, command=lambda:removeUser(usernEnt, passEnt)) 
    chgpassBut.place(x=70,y=310)

    returnBut = tk.Button(BodyFrame, text = "Return to Main Page", padx=10, command=lambda:returnToMain(AdminChanges, window))
    returnBut.place(x=70,y=390)

    window.mainloop()


if __name__ == "__main__":
    Set()
