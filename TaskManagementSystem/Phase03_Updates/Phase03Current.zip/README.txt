All of these files are required together in order for the TMS to work properly,
this includes the images!