'''
Main Window
'''

import datetime
from tkinter import *
from tkinter.ttk import *

# Class template for now

class User():
    
    def __init__(self,u,p):
        self.username=u
        self.password=p
        self.numOfTasks=0
        self.admin=False
        self.loggedIn=False

    def setUsername(self,u): #userame:str
        self.username=u 
    def setPassword(self,p): #password:str
        self.password=p
    def setNumOfTasks(self,n): #numOfTasks:int
        self.numOfTasks=n
    def setAdminStatus(self,a): #admin:boolean
        self.admin=a
    def setLoginStatus(self,log): #loggedIn:boolean
        self.loggedIn = log
        
    def getUsername(self):
        return self.username
    def getPassword(self):
        return self.password
    def getnumOfTasks(self):
        return self.numOfTasks
    def getAdminStatus(self):
        return self.admin
    def getLoginStatus(self):
        return self.loggedIn

    def addToTaskCount(self): ##adds to the number of tasks saved counter for the user
        self.numOfTasks+=1
        return self.numOfTasks

    def removeFromTaskCount(self): ##subtracts from the number of tasks saved counter for the user
        self.numOfTasks-=1
        return self.numOfTasks
    


class Task(User):
    '''Class representing a task in TMS'''
    def __init__(self,u,p,t,dat,tim,dur,des):
        User.__init__(self,u,p) #(self,u,p,n,a)
        self.title=t
        self.date=dat
        self.time=tim ##use military time (it'll be easier) unless datetime object works
        self.duration=dur ##in hours or minutes? I think hours.
        self.description=des

    #def __str__(self):
        #return "{} {} {} {} {} {} {}".format(self.username, self.password, self.title, self.date,
                #self.time, self.duration, self.description)

    def setTitle(self,t):
        self.title=t
    def setDate(self,dat):
        self.date=dat
    def setTime(self,tim):
        self.time=tim
    def setDuration(self,dur):
        self.duration=dur
    def setDescription(self,des):
        self.description=des

    def getTitle(self):
        return self.title    
    def getDate(self):
        return self.date    
    def getTime(self):
        return self.time  
    def getDuration(self):
        return self.duration  
    def getDescription(self):
        return self.description

    def saveTask(self):
        ##this is where the username and
        ##all Task attributes will be saved to a csv file.
        infoList = [self.username, self.title, self.date, self.time, self.duration, self.description]
        with open ('CSV.csv', 'a', newline = '') as file:
            csvWriter = csv.writer(file)
            csvWriter.writerow(infoList)



##CURRENT_DAY = datetime.date.today()
window = Tk()
window.title('Task Management System')
window.geometry('550x500')
##window.configure(bg="Green")
BG_COLOR = "Green"
FG_COLOR = "White"


#Welcome Banner
welcFrame = Frame(master=window)
welcomeBanner = Label(welcFrame, text="[User]'s Calendar",
                      font = ("Comic Sans MS",20))
welcomeBanner.pack(side=LEFT)
welcFrame.pack()


#Months and Years as combo boxes + go button
monthsFrame = Frame(master=window)#, bg="Green")
monthsCombo = Combobox(monthsFrame)
monthsCombo['values']= ("January", "February", "March", "April",
                  "May", "June", "July", "August",
                  "September","October","November","December")
monthsCombo.current(1)
monthsCombo.pack(side=LEFT)
yearsCombo = Combobox(monthsFrame)
yearsCombo['values']= ("2022", "2023", "2024", "2025",
                  "2026", "2027", "2028", "2029",
                  "2030","2031","2032","2033")
yearsCombo.current(1)
yearsCombo.pack(side=LEFT)


#Changes calendar to reflect selected info
goButtonCal = Button(monthsFrame, text="Go")
goButtonCal.pack(side=LEFT)
monthsFrame.pack()


##Calendar as buttons
calendarFrame=Frame(master=window)#, bg="Green")
dayNum=0
days = ["Mon", "Tue","Wed","Thu","Fri","Sat", "Sun"]
dateToday = datetime.date.today()


##creates a label for each weekday starting with monday
for d in range(len(days)):
    weekdayLabel = Label(calendarFrame, text=days[d],font=("Comic Sans MS", 12))
    weekdayLabel.grid(column=d, row=0)

##Creates a button for each day
##when clicked, the current tasks will appear
##or a message saying there are no tasks for that day
    m=True##placeholder for datetime condition
for i in range(5):
    for j in range(7):
        ##frame = tk.Frame(master=window)
        if dayNum > 30:
            break
        else:
            if m==True:
                ##placeholder for datetime,
                ##need int value representing day of the week (0-6)
                ##for the 1st day of the month.
                ##if month-1-year is on m=weekday (0-6)
                ##print m labels
                label= Label(calendarFrame, text="   ")
                label.grid(row=i+1, column=j, sticky='nsew')
                m=False
            else:
                dayNum+=1
                button = Button(calendarFrame, text=f"{dayNum}")
                button.grid(row=i+1, column=j, sticky='nsew')
calendarFrame.pack()


##Frame for search function
searchFrame = Frame(master=window)
searchLabel=Label(searchFrame, text="Search by:", font=("Comic Sans MS", 10))
searchLabel.pack(side=LEFT)
searchByCombo = Combobox(searchFrame)
searchByCombo['values']= ("Month", "Day", "Year", "Time",
                  "Title", "Duration", "Description")
searchByCombo.current(1)
searchByCombo.pack(side=LEFT)
goButtonSearch = Button(searchFrame, text="Go")
goButtonSearch.pack(side=LEFT)
searchFrame.pack()

##Frame for task related options
##including task list,
##task options (add, edit, remove)

taskFrame = Frame(master=window)
taskLabelFrame = LabelFrame(taskFrame, text='Current Tasks')


##if tasks exist for that search. else, label says: "There are no tasks scheduled for this day"
task = Radiobutton(taskLabelFrame, text="placeholder") ##find way to click away and clear selection?
task.pack()
taskLabelFrame.pack()

import Remove
import Add
import Edit
#import Search as Sh
import Settings

addButton = Button(taskFrame, text= "Add New Task",
                   command = Add.Add)##default to selected day
editButton = Button(taskFrame, text= "Edit Selected Task",
                    command = Edit.Edit) ##if not selected, "please select a task"
removeButton = Button(taskFrame, text= "Remove Selected Task",
                      command = Remove.RemoveWin)##same as above and also "Are you sure?"
addButton.pack()
editButton.pack()
removeButton.pack()
settingsButton=Button(taskFrame, text="User Settings",
                      command = Settings.Set)
settingsButton.pack()

taskFrame.pack()
